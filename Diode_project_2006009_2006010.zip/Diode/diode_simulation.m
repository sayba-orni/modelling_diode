clc
clear all
close all
format long
FRONTPAGE